﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Evolent.Api.Contacts.Controllers;
using Evolent.Contacts.Business.Manager;
using Evolent.Contacts.Model;
using System.Collections.Generic;
namespace Evolent.Api.Contacts.Test
{
    [TestClass]
    public class ContactsTest
    {
        private readonly ContactsManager _manager = null;

        public ContactsTest()
        {
            _manager = new ContactsManager();
        }
        [TestMethod]
        public void GetAllContacts()
        {
            var testResults = _manager.GetAllContacts() as List<ContactsInfo>;
            var controller = new ContactsDetailsController(new ContactsManager());

            var results = controller.Get() as List<ContactsInfo>;

            Assert.AreEqual(testResults.Count, results.Count);

        }

        [TestMethod]
        public void InsertNewContacts()
        {
            ContactsInfo _contacts = new ContactsInfo();
            _contacts.FirstName = "Raam";
            _contacts.LastName = "Dubey";
            _contacts.EmailID = "raam.dubey@gmail.com";
            _contacts.PhoneNumber = "9860859685";
            _contacts.Status = "Active";

            var controller = new ContactsDetailsController(new ContactsManager());

            var results = controller.Post(_contacts);

            Assert.AreNotEqual(0, results);

        }

        [TestMethod]
        public void InsertNewWrongInfoContacts()
        {
            ContactsInfo _contacts = new ContactsInfo();
            _contacts.FirstName = "Shyam";
            _contacts.LastName = "Sharma";
            _contacts.EmailID = "Shyam.Sharma@gmail.com";
            _contacts.PhoneNumber = "9860859685";
            _contacts.Status = "Test";

            var controller = new ContactsDetailsController(new ContactsManager());

            var results = controller.Post(_contacts);

            Assert.AreNotEqual(0, results);

        }
    }
}
