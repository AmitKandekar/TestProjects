﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Evolent.Contacts.Model
{
    public class ContactsInfo
    {
       [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity), Key()]
        public int ContactsID { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string EmailID { get; set; }
        [Required]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid phone number")]
        public string PhoneNumber { get; set; }
        [Required]
        [StringRange(AllowableValues = new[] { "Active", "Inactive" }, ErrorMessage = "Status must be either 'Active' or 'Inactive'.")]
        public string Status { get; set; }
    }

   public class StringRangeAttribute : ValidationAttribute
{
    public string[] AllowableValues { get; set; }

    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        if (AllowableValues != null? AllowableValues.Contains(value.ToString()) == true : false)
        {
            return ValidationResult.Success;
        }

        var msg = "Status must be either 'Active' or 'Inactive'.";
        return new ValidationResult(msg);
    }
}
}
