﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Practices.Unity;
using System.Web.Mvc;
using Evolent.Api.Contacts.Extensions;


namespace Evolent.Api.Contacts
{
    public class UnityControllerfactoryConfig
    {
        public static void RegisterUnityControllerFactory()
        {
            IUnityContainer container = new UnityContainer();

            var factory = new UnityControllerFactory(container);

            ControllerBuilder.Current.SetControllerFactory(factory);
        }
    }
}