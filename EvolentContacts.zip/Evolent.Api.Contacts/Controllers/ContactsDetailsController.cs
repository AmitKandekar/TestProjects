﻿using Evolent.Api.Contacts.Filters;
using Evolent.Contacts.Business.Manager;
using Evolent.Contacts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Evolent.Api.Contacts.Controllers
{
    public class ContactsDetailsController : ApiController
    {
        private readonly IContactsManager _contactsMananger;

        public ContactsDetailsController(IContactsManager ContactsMananger)
        {
            this._contactsMananger = ContactsMananger;
        }
        // GET api/testcontacts
        public IEnumerable<ContactsInfo> Get()
        {
           return  _contactsMananger.GetAllContacts();
        }

        // GET api/testcontacts/5
        public ContactsInfo Get(int id)
        {
            return _contactsMananger.GetAllContactsByID(id);
        }

        // POST api/testcontacts
        [ValidateModel]
        public int Post(ContactsInfo newContact)
        {
           return _contactsMananger.AddNewContact(newContact);
        }

        // PUT api/testcontacts/5
        [ValidateModel]
        public void Put(int id, ContactsInfo editContact)
        {
            _contactsMananger.EditContactByID(id, editContact);
        }

        // DELETE api/testcontacts/5
        public void Delete(int id)
        {
            _contactsMananger.DeleteContactByID(id);
        }
    }
}
