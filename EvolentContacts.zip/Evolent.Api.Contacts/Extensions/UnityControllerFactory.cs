﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using System.Web.Routing;
using System.Web.Http.Dispatcher;
using System.Web.Http.Dependencies;

namespace Evolent.Api.Contacts.Extensions
{
    public class UnityControllerFactory : DefaultControllerFactory
    {
        public readonly IUnityContainer _container;

        public UnityControllerFactory(IUnityContainer container)
        {
            this._container = container;
            var containerTemp = this._container.LoadConfiguration();

            //Container.LoadConfiguration();
        }

        protected override IController GetControllerInstance(RequestContext requestContext, Type controllerType)
        {
            if (controllerType == null)
                return null;
            return _container.Resolve(controllerType) as IController;
        }
    }


    //public interface IDependencyResolver : IDependencyScope, IDisposable
    //{
    //    IDependencyScope BeginScope();
    //}

    //public interface IDependencyScope : IDisposable
    //{
    //    object GetService(Type serviceType);
    //    IEnumerable<object> GetServices(Type serviceType);
    //}


    public class UnityResolver : System.Web.Http.Dependencies.IDependencyResolver
    {
        protected IUnityContainer container;

        public UnityResolver(IUnityContainer container)
        {
            if (container == null)
            {
                throw new ArgumentNullException("container");
            }
            this.container = container;
        }

        public object GetService(Type serviceType)
        {
            try
            {
                return container.Resolve(serviceType);
            }
            catch (ResolutionFailedException)
            {
                return null;
            }
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            try
            {
                return container.ResolveAll(serviceType);
            }
            catch (ResolutionFailedException)
            {
                return new List<object>();
            }
        }

        public IDependencyScope BeginScope()
        {
            var child = container.CreateChildContainer();
            return new UnityResolver(child);
        }

        public void Dispose()
        {
            Dispose(true);
        }

        protected virtual void Dispose(bool disposing)
        {
            container.Dispose();
        }
    }
}