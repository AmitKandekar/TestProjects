namespace Evolent.Contacts.Business.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ContactsInfoes",
                c => new
                    {
                        ContactsID = c.Int(nullable: false, identity: true),
                        FirstName = c.String(nullable: false),
                        LastName = c.String(nullable: false),
                        EmailID = c.String(nullable: false),
                        PhoneNumber = c.String(nullable: false),
                        Status = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.ContactsID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.ContactsInfoes");
        }
    }
}
