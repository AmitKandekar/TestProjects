﻿using Evolent.Contacts.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Evolent.Contacts.Business.Context
{
    public class EvolentContactsContext : DbContext
    {
        public EvolentContactsContext() : base("name = EvolentContactsContext") { }

        public virtual DbSet<ContactsInfo> ContactsDetails { get; set; }
    }
}
