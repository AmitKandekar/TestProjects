﻿using Evolent.Contacts.Business.Context;
using Evolent.Contacts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Evolent.Contacts.Business.Repository
{
    public class ContactsRepository
    {
        public readonly EvolentContactsContext _dal;
        //public readonly
        public ContactsRepository()
        {
            _dal = new EvolentContactsContext();
        }
        public IEnumerable<ContactsInfo> GetAllContacts()
        {
           return _dal.ContactsDetails.OrderBy(c => c.ContactsID).ToList();
        }

        public ContactsInfo GetAllContactsByID(int id)
        {
            ContactsInfo _contact = _dal.ContactsDetails.Where(c => c.ContactsID == id).FirstOrDefault();

            if (_contact != null)
                return _contact;
            else
              return new ContactsInfo();
        }

        public bool EditContactByID(int id, ContactsInfo contactsInfo)
        {
             ContactsInfo _contact = _dal.ContactsDetails.Where(c => c.ContactsID == id).FirstOrDefault();

            if (_contact != null)
            {
                _contact.FirstName = contactsInfo.FirstName;
                _contact.LastName = contactsInfo.LastName;
                _contact.EmailID = contactsInfo.EmailID;
                _contact.Status = contactsInfo.Status;

                _dal.SaveChanges();
            }

           
            return true;
        }

        public bool DeleteContactByID(int contactID)
        {
            ContactsInfo _contact = _dal.ContactsDetails.Where(c => c.ContactsID == contactID).FirstOrDefault();

             if (_contact != null)
             {
                 _dal.ContactsDetails.Remove(_contact);

                 _dal.SaveChanges();
             }

             return true;
        }

        public int AddNewContact(ContactsInfo newContact)
        {
            _dal.ContactsDetails.Add(newContact);
            _dal.SaveChanges();

            return newContact.ContactsID;
        }
    }
}
