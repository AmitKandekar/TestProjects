﻿using Evolent.Contacts.Business.Repository;
using Evolent.Contacts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Evolent.Contacts.Business.Manager
{
    public class ContactsManager : IContactsManager
    {
        public readonly ContactsRepository _contactRepository;

        public ContactsManager()
        {
            _contactRepository = new ContactsRepository();
        }

        public IEnumerable<ContactsInfo> GetAllContacts()
        {
            return _contactRepository.GetAllContacts();
        }

        public ContactsInfo GetAllContactsByID(int id)
        {
           return _contactRepository.GetAllContactsByID(id);
        }

        public bool EditContactByID(int id,ContactsInfo contactsID)
        {
           return _contactRepository.EditContactByID(id, contactsID);
        }

        public bool DeleteContactByID(int contactID)
        {
           return _contactRepository.DeleteContactByID(contactID);
        }

        public int AddNewContact(ContactsInfo newContact)
        {
           return _contactRepository.AddNewContact(newContact);
        }
    }
}
