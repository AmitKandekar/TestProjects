﻿using Evolent.Contacts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Evolent.Contacts.Business.Manager
{
   public interface IContactsManager
    {
       IEnumerable<ContactsInfo> GetAllContacts();
       ContactsInfo GetAllContactsByID(int id);
       bool EditContactByID(int id,ContactsInfo contactsID);
       bool DeleteContactByID(int contactID);
       int AddNewContact(ContactsInfo newContact);
    }
}
